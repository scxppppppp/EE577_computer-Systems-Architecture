#include <stdio.h>

void
main(void)
{
  char str[] = "Hello world...";

  fprintf(stdout, "str = %s\n", str);
  exit(0);
}
 
